package meteordevelopment.meteorclient.mixin;

import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.XRay;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Block.class)
public abstract class BlockMixin {

    /**
     * @author HELLxCLIENT Team
     * @reason Optimized X-Ray rendering logic for 1.21.x
     */
    @Inject(method = "shouldSideBeRendered", at = @At("HEAD"), cancellable = true)
    private static void onShouldSideBeRendered(BlockState state, BlockGetter world, BlockPos pos, Direction side, BlockPos neighborPos, CallbackInfoReturnable<Boolean> info) {
        XRay xray = Modules.get().get(XRay.class);

        if (xray != null && xray.isActive()) {
            // Force visibility only for blocks in the HELLx-Xray list
            info.setReturnValue(xray.isVisible(state.getBlock()));
        }
    }

    @Inject(method = "isShapeFullBlock", at = @At("HEAD"), cancellable = true)
    private void onIsShapeFullBlock(BlockState state, BlockGetter world, BlockPos pos, CallbackInfoReturnable<Boolean> info) {
        if (Modules.get().isActive(XRay.class)) {
            info.setReturnValue(true); // Prevents visual glitches when X-ray is on
        }
    }
}