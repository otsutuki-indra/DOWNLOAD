package meteordevelopment.meteorclient;

import meteordevelopment.meteorclient.addons.AddonManager;
import meteordevelopment.meteorclient.systems.Systems;
import meteordevelopment.meteorclient.systems.modules.Categories;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.Minecraft;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MeteorClient implements ClientModInitializer {
    public static final String MOD_ID = "hellx-client";
    public static final String NAME = "HELLxCLIENT";
    public static final String VERSION = "v1.0";
    public static final Logger LOG = LoggerFactory.getLogger(NAME);
    public static MeteorClient INSTANCE;
    public static Minecraft mc;

    @Override
    public void onInitializeClient() {
        if (INSTANCE != null) return;
        INSTANCE = this;
        mc = Minecraft.getInstance();

        LOG.info("Initializing {} {}", NAME, VERSION);

        // Core Systems
        Categories.init();
        Systems.init();
        AddonManager.init();
        
        // Finalize
        Modules.get().sortModules();
        Systems.load();

        Runtime.getRuntime().addShutdownHook(new Thread(Systems::save));
    }
}