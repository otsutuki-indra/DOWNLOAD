# HELLxCLIENT v1

![License](https://img.shields.io/badge/License-MIT-red.svg)
![Version](https://img.shields.io/badge/Version-1.0-orange.svg)
![Platform](https://img.shields.io/badge/Platform-Fabric-blue.svg)

**HELLxCLIENT** is a high-performance, optimized utility mod built on the Meteor framework. Designed for maximum efficiency and brutal objectivity in competitive environments.

---

## 🚀 Features

### ⚔️ Combat (HELLx-Combat)
*   **KillAura Pro**: Advanced rotation smoothing with Gaussian jitter to bypass modern Anti-Cheats (Grim, Vulcan).
*   **Reach Pro**: Customizable interaction range with smart distance buffering.
*   **SmartCrit**: Guaranteed critical hits by synchronizing attacks with fall distance.

### 🛠️ Utility & Misc
*   **FastUse Pro**: Instant consumable usage via packet-based optimization.
*   **SpeedMine Pro**: Removes block-hit delay and modifies destruction progress for instant mining.
*   **General Disabler**: Advanced packet-spoofing logic to confuse server-side checks.
*   **Ping Spoof**: Manipulates `KeepAlive` packets to simulate lag and bypass movement flags.

### 🌐 Social & UI
*   **Rich Presence**: Professional Discord integration showing your dominance with HELLxCLIENT.
*   **Custom Prefix**: Fully configurable command system (Default: `!`).
*   **Optimized GUI**: Categorized modules for lightning-fast navigation.

---

## 🛠️ Installation & Build

### Requirements
*   **Java 26** (Required for Minecraft 1.21.x)
*   **Fabric Loader**

### Building from Source
1. Clone the repository.
2. Open a terminal in the root directory.
3. Run the following command:
   ```bash
   ./gradlew clean build