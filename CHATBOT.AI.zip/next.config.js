/*========================================================================
 * Cloudflare Pages Deployment Note
 * This project uses Vite for instant compilation in the AI Studio environment.
 * If you migrate this codebase structure to Next.js in your local environment,
 * use this configuration to enable static exports for Cloudflare Pages.
 *========================================================================*/

/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  // Optional: disable image optimization since Cloudflare Pages static hosting doesn't support the Next.js image server natively without configuring a worker
  images: {
    unoptimized: true,
  },
}

export default nextConfig;
