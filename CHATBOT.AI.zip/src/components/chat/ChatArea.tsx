import React, { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import remarkGfm from 'remark-gfm';
import { Copy, ThumbsUp, ThumbsDown, Check } from 'lucide-react';
import { useState } from 'react';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  isStreaming?: boolean;
}

const CodeBlock = ({ inline, className, children, ...props }: any) => {
  const match = /language-(\w+)/.exec(className || '');
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(String(children).replace(/\n$/, ''));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!inline && match) {
    return (
      <div className="relative group mt-4 mb-4 rounded-xl overflow-hidden border border-white/10">
        <div className="flex items-center justify-between px-4 py-1.5 bg-[#111] border-b border-white/5 backdrop-blur-md">
          <span className="text-[10px] uppercase tracking-wider text-white/50 font-mono">{match[1]}</span>
          <button 
            onClick={handleCopy}
            className="text-white/40 hover:text-white/90 transition-colors p-1"
            title="Copy code"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>
        <SyntaxHighlighter
          style={vscDarkPlus as any}
          language={match[1]}
          PreTag="div"
          customStyle={{ margin: 0, padding: '1rem', background: 'rgba(0,0,0,0.3)' }}
          {...props}
        >
          {String(children).replace(/\n$/, '')}
        </SyntaxHighlighter>
      </div>
    );
  }
  return (
    <code className="bg-white/10 text-white/90 px-1.5 py-0.5 rounded-md font-mono text-[0.9em]" {...props}>
      {children}
    </code>
  );
};

function MessageBubble({ msg }: { msg: Message }) {
  const isUser = msg.role === 'user';
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      className={`flex w-full ${isUser ? 'justify-end' : 'justify-start'} mb-8`}
    >
      <div 
        className={`max-w-[85%] md:max-w-[80%] relative group ${
          isUser 
            ? 'bg-gradient-to-r from-[#222] via-[#2a2a2a] to-[#222] bg-[length:200%_auto] animate-[gradient-x_3s_ease_infinite] text-white shadow-sm rounded-2xl p-5 ml-auto border border-[#333]' 
            : 'w-full px-2 md:px-0'
        }`}
      >
        {/* Content */}
        <div className="relative z-10 flex flex-col">
          {/* Avatar / Name */}
          <div className="flex items-center space-x-2 mb-3 mt-1">
            {isUser ? (
              <span className="text-[10px] uppercase tracking-widest text-[#888] font-mono ml-auto">You</span>
            ) : (
              <>
                <div className="w-6 h-6 rounded-md bg-white/10 flex items-center justify-center border border-white/5">
                   <div className="w-2 h-2 rounded-sm bg-white" />
                </div>
                <span className="text-xs font-semibold tracking-wide text-white/80 uppercase font-mono">Hellx System</span>
              </>
            )}
          </div>

          <div className={`prose prose-invert prose-p:leading-relaxed prose-pre:m-0 max-w-none ${isUser ? 'text-[#eee]' : 'text-white/80'}`}>
            {isUser ? (
              <p className="whitespace-pre-wrap font-serif text-[17px] tracking-wide leading-relaxed">{msg.content}</p>
            ) : (
              <div className="font-serif text-[16px] leading-[1.8] tracking-wide">
                <ReactMarkdown
                  remarkPlugins={[remarkGfm]}
                  components={{
                    code: CodeBlock,
                    p: ({node, ...props}) => <p className="mb-4 last:mb-0" {...props} />,
                    ul: ({node, ...props}) => <ul className="list-disc ml-6 mb-4 space-y-1 text-white/70" {...props} />,
                    ol: ({node, ...props}) => <ol className="list-decimal ml-6 mb-4 space-y-1 text-white/70" {...props} />,
                    h1: ({node, ...props}) => <h1 className="text-2xl font-bold mt-6 mb-4 text-white font-sans" {...props} />,
                    h2: ({node, ...props}) => <h2 className="text-xl font-semibold mt-5 mb-3 text-white font-sans" {...props} />,
                    h3: ({node, ...props}) => <h3 className="text-lg font-medium mt-4 mb-2 text-white font-sans" {...props} />,
                    a: ({node, ...props}) => <a className="text-white hover:text-white/80 underline decoration-white/20 hover:decoration-white/60 transition-all cursor-pointer" {...props} />,
                  }}
                >
                  {msg.content}
                </ReactMarkdown>
                {!isUser && msg.isStreaming && (
                  <span className="inline-block w-1.5 h-4 ml-1 bg-white/50 animate-pulse align-middle" />
                )}
              </div>
            )}
          </div>

          {/* Assistant Actions */}
          {!isUser && !msg.isStreaming && (
            <div className="flex items-center space-x-2 mt-4 pt-3 border-t border-white/5 opacity-0 group-hover:opacity-100 transition-opacity">
              <button className="p-1.5 text-white/30 hover:text-white hover:bg-white/10 rounded-md transition-colors">
                <ThumbsUp className="w-3.5 h-3.5" />
              </button>
              <button className="p-1.5 text-white/30 hover:text-white hover:bg-white/10 rounded-md transition-colors">
                <ThumbsDown className="w-3.5 h-3.5" />
              </button>
              <div className="w-px h-3 bg-white/10 mx-1" />
              <button 
                onClick={() => navigator.clipboard.writeText(msg.content)}
                className="p-1.5 text-white/30 hover:text-white hover:bg-white/10 rounded-md transition-colors"
                title="Copy full response"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

export function ChatArea({ 
  messages, 
  isLoading,
  selectedModel
}: { 
  messages: Message[];
  isLoading: boolean;
  selectedModel: string;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  if (messages.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-center relative overflow-hidden">
        {/* Decorative Grid */}
        <div className="absolute inset-0 opacity-[0.02]" style={{ backgroundImage: `radial-gradient(circle at center, #fff 1px, transparent 1px)`, backgroundSize: '30px 30px' }} />
        
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative z-10 max-w-md mx-auto"
        >
          <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-white/5 flex flex-col items-center justify-center p-2 border border-white/10 shadow-xl">
            <div className="w-full h-full bg-[#111] rounded-xl flex items-center justify-center font-bold text-2xl text-white font-serif">
              {selectedModel === 'gemini' ? 'U' : selectedModel === 'sambanova' ? 'N' : 'C'}
            </div>
          </div>
          <h2 className="text-2xl font-bold tracking-tight mb-3 text-white/90 font-serif">System Ready</h2>
          <p className="text-white/40 text-[15px] tracking-wide leading-relaxed font-sans font-light">
            Neural link established. Awaiting input to begin sequence.
          </p>
        </motion.div>
      </div>
    );
  }

  return (
    <div 
      className="flex-1 overflow-y-auto px-4 py-6 md:px-8 custom-scrollbar relative z-10"
      ref={scrollRef}
    >
      <div className="max-w-4xl mx-auto flex flex-col">
        {messages.map(msg => (
          <MessageBubble key={msg.id} msg={msg} />
        ))}
        
        {isLoading && messages[messages.length - 1]?.role === 'user' && (
          <div className="flex w-full justify-start mb-8">
            <div className="text-white/40 flex items-center space-x-2 text-sm font-sans tracking-wide">
              <div className="flex space-x-1">
                 <div className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '0ms' }} />
                 <div className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '150ms' }} />
                 <div className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        
        {/* Extra padding at bottom for input */}
        <div className="h-6" />
      </div>
    </div>
  );
}
