import { Send, Mic, Image as ImageIcon, Paperclip } from 'lucide-react';
import { motion } from 'framer-motion';
import { useState, useRef, useEffect } from 'react';

export function ChatInput({ 
  onSend, 
  disabled 
}: { 
  onSend: (text: string) => void;
  disabled: boolean;
}) {
  const [input, setInput] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      // Max height ~200px
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  const handleSend = () => {
    if (input.trim() && !disabled) {
      onSend(input);
      setInput('');
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto relative px-4 md:px-8 pb-6 pt-2 z-20">
      <div className="relative bg-[#111111]/80 backdrop-blur-md rounded-[28px] p-2 border border-white/10 shadow-lg focus-within:border-white/20 transition-all duration-300">
        
        <div className="relative flex flex-col pt-1">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Your message to Hellx..."
            disabled={disabled}
            className="w-full bg-transparent text-[16px] px-4 py-3 resize-none focus:outline-none max-h-[200px] min-h-[50px] text-white/90 placeholder:text-white/30 tracking-wide font-serif leading-relaxed custom-scrollbar"
            style={{ 
              scrollbarWidth: 'thin',
              scrollbarColor: 'rgba(255, 255, 255, 0.1) transparent'
            }}
          />

          <div className="flex items-center justify-between px-2 pt-1 pb-1">
            {/* Left Actions */}
            <div className="flex items-center space-x-1">
              <button 
                type="button"
                className="w-9 h-9 rounded-full hover:bg-white/5 flex items-center justify-center transition-colors text-white/40 hover:text-white/80 group pointer-events-auto"
                title="Attach file"
              >
                <Paperclip className="w-4 h-4" />
              </button>
              <button 
                type="button"
                className="w-9 h-9 rounded-full hover:bg-white/5 flex items-center justify-center transition-colors text-white/40 hover:text-white/80 group pointer-events-auto"
                title="Upload image"
              >
                <ImageIcon className="w-4 h-4" />
              </button>
            </div>

            {/* Right Actions */}
            <div className="flex items-center space-x-2">
              <button 
                type="button"
                className="w-9 h-9 rounded-full hover:bg-white/5 flex items-center justify-center transition-colors text-white/30 hover:text-white/80 group pointer-events-auto"
              >
                <Mic className="w-4 h-4" />
              </button>

              <button
                onClick={handleSend}
                disabled={!input.trim() || disabled}
                className={`flex items-center justify-center w-10 h-10 rounded-full font-bold shadow-sm transition-all ${
                  input.trim() && !disabled 
                    ? 'bg-white text-black hover:scale-105 cursor-pointer' 
                    : 'bg-white/5 text-white/20 cursor-not-allowed'
                }`}
              >
                <Send className="w-4 h-4 ml-0.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-4 text-center text-[10px] text-white/30 font-sans font-light">
        Hellx A.I may produce inaccurate information. Please verify important details.
      </div>
    </div>
  );
}
