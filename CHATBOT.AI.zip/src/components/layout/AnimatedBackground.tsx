import { motion } from 'framer-motion';

export function AnimatedBackground() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-[-1] bg-gradient-to-br from-[#1e1e1e] via-[#111111] to-[#000000]">
      {/* Light subtle glow in the center */}
      <div 
        className="absolute inset-0 opacity-[0.15] pointer-events-none"
        style={{
          background: 'radial-gradient(circle at 50% 0%, #444 0%, transparent 70%)',
        }}
      />
      {/* Subtle bottom glow */}
      <div 
        className="absolute bottom-0 left-0 right-0 h-[50vh] opacity-10 pointer-events-none"
        style={{
          background: 'linear-gradient(to top, #333 0%, transparent 100%)',
        }}
      />
    </div>
  );
}
