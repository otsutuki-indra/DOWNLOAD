import { Settings, PlusSquare, MessageSquare, Menu, Cpu, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const MODELS = [
  { id: 'gemini', name: 'Hellx Ultra', vendor: 'Google Gemini', icon: Sparkles, color: 'text-white' },
  { id: 'sambanova', name: 'Hellx Nova', vendor: 'SambaNova', icon: Cpu, color: 'text-white/60' },
  { id: 'cloudflare', name: 'Hellx Cloud', vendor: 'Workers AI', icon: MessageSquare, color: 'text-white/60' },
];

export function Sidebar({ 
  onNewChat,
  isMobileOpen,
  setMobileOpen,
  selectedModel,
  setSelectedModel
}: { 
  onNewChat: () => void;
  isMobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
  selectedModel: string;
  setSelectedModel: (m: string) => void;
}) {

  return (
    <>
      {/* Mobile overlay */}
      <AnimatePresence>
        {isMobileOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setMobileOpen(false)}
            className="md:hidden fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
          />
        )}
      </AnimatePresence>

      <motion.aside
        className={`fixed md:static inset-y-0 left-0 z-50 w-72 h-full bg-[#050505] border-r border-white/5 flex flex-col transition-transform duration-300 md:translate-x-0 ${isMobileOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="p-5 flex flex-col h-full relative">
          
          {/* Logo Area */}
          <div className="flex items-center justify-between mb-10 px-2 mt-2">
            <h1 className="text-2xl font-bold tracking-tight text-white/90 font-serif">
              Hellx <span className="font-light text-white/50">A.I</span>
            </h1>
            <button 
              onClick={onNewChat}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors group"
              title="New Chat"
            >
              <PlusSquare className="w-5 h-5 text-white/50 group-hover:text-white" />
            </button>
          </div>

          {/* 3 Different Chat Box / Model Selector */}
          <div className="mb-8">
            <div className="text-[10px] font-mono text-white/30 mb-4 px-2 uppercase tracking-widest">Neural Link Connections</div>
            
            <div className="flex flex-col space-y-2">
              {MODELS.map(model => (
                <button 
                  key={model.id}
                  onClick={() => {
                    setSelectedModel(model.id);
                    if(isMobileOpen) setMobileOpen(false);
                  }}
                  className={`flex items-center space-x-3 p-3 rounded-xl transition-all border text-left ${
                    selectedModel === model.id 
                      ? 'bg-gradient-to-r from-white/10 to-transparent border-white/10 shadow-sm' 
                      : 'bg-transparent border-transparent hover:bg-white/5'
                  }`}
                >
                  <div className={`p-2 rounded-lg flex-shrink-0 ${selectedModel === model.id ? 'bg-white/10' : 'bg-transparent'}`}>
                    <model.icon className={`w-4 h-4 ${selectedModel === model.id ? 'text-white' : 'text-white/40'}`} />
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <div className={`text-sm font-medium truncate ${selectedModel === model.id ? 'text-white' : 'text-white/60'}`}>
                      {model.name}
                    </div>
                    <div className="text-[10px] text-white/40 tracking-wide truncate">{model.vendor}</div>
                  </div>
                  {selectedModel === model.id && (
                     <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse flex-shrink-0" />
                  )}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1 overflow-y-auto pr-2 -mr-2">
            {/* Nav area clear */}
          </div>

          {/* Settings / Bottom Controls */}
          <div className="pt-4 mt-4 border-t border-white/5 px-2">
             <div className="text-[10px] text-white/20 uppercase tracking-widest font-mono text-center">
               Hellx Network Active
             </div>
          </div>
        </div>
      </motion.aside>
    </>
  );
}
