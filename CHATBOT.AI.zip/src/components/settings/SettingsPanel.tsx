import { motion } from 'framer-motion';
import { Settings, X, Palette, Key, Shield, Zap, Sparkles } from 'lucide-react';
import { Slider } from '@/components/ui/slider';

// Defined types for our app settings
export interface AppSettings {
  ui: {
    glowIntensity: number; // 0-100
    animationSpeed: number; // 0-100
    particleDensity: number; // 0-100
  };
}

export function SettingsPanel({
  isOpen,
  onClose,
  settings,
  updateSettings
}: {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  updateSettings: (newSettings: Partial<AppSettings>) => void;
}) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center pointer-events-auto">
      {/* Backdrop */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/60 backdrop-blur-md"
      />
      
      {/* Modal / Panel */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="relative w-full max-w-2xl mx-4 max-h-[85vh] overflow-y-auto custom-scrollbar glass-panel-heavy border-white/10 rounded-2xl p-6 md:p-8"
      >
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 text-white/50 hover:text-white hover:bg-white/10 p-2 rounded-full transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3 mb-8">
          <Settings className="w-8 h-8 text-white animate-spin-slow" />
          <h2 className="text-3xl font-bold font-mono tracking-widest uppercase">System Configuration</h2>
        </div>

        <div className="flex flex-col gap-8 max-w-sm mx-auto">
          {/* Visual Tuning Column */}
          <div className="space-y-6">
            <div className="flex items-center space-x-2 text-white/80 border-b border-white/10 pb-2">
              <Palette className="w-4 h-4 text-white/80" />
              <h3 className="text-lg font-mono tracking-wide uppercase">Visual Tuning</h3>
            </div>
            
            <div className="space-y-6 text-sm font-sans pt-2">
              {/* Glow Intensity Slider */}
              <div className="space-y-3">
                 <div className="flex items-center justify-between text-white/60 uppercase font-mono tracking-wider text-[11px]">
                    <span className="flex items-center"><Zap className="w-3 h-3 mr-1 text-white/80"/> Glow Intensity</span>
                    <span>{settings.ui.glowIntensity}%</span>
                 </div>
                 <Slider
                    value={[settings.ui.glowIntensity]}
                    onValueChange={(val) => updateSettings({ ui: { ...settings.ui, glowIntensity: val[0] } })}
                    max={100}
                    step={1}
                 />
              </div>

              {/* Animation Speed */}
              <div className="space-y-3">
                 <div className="flex items-center justify-between text-white/60 uppercase font-mono tracking-wider text-[11px]">
                    <span className="flex items-center"><Sparkles className="w-3 h-3 mr-1 text-white/80"/> Animation Speed</span>
                    <span>{settings.ui.animationSpeed}%</span>
                 </div>
                 <Slider
                    value={[settings.ui.animationSpeed]}
                    onValueChange={(val) => updateSettings({ ui: { ...settings.ui, animationSpeed: val[0] } })}
                    max={100}
                    step={1}
                 />
              </div>

              {/* Particle Density */}
              <div className="space-y-3">
                 <div className="flex items-center justify-between text-white/60 uppercase font-mono tracking-wider text-[11px]">
                    <span className="flex items-center"><Shield className="w-3 h-3 mr-1 text-white/80"/> Particle Density</span>
                    <span>{settings.ui.particleDensity}%</span>
                 </div>
                 <Slider
                    value={[settings.ui.particleDensity]}
                    onValueChange={(val) => updateSettings({ ui: { ...settings.ui, particleDensity: val[0] } })}
                    max={100}
                    step={1}
                 />
              </div>
            </div>
          </div>
        </div>

      </motion.div>
    </div>
  );
}
