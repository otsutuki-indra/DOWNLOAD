import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu } from 'lucide-react';
import { Sidebar } from './components/layout/Sidebar';
import { AnimatedBackground } from './components/layout/AnimatedBackground';
import { ChatArea, Message } from './components/chat/ChatArea';
import { ChatInput } from './components/chat/ChatInput';
import { generateChatStream, ModelType, ChatMessageData } from './lib/ai-models';

export default function App() {
  const [isLanding, setIsLanding] = useState(true);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedModel, setSelectedModel] = useState<string>('gemini');
  
  const [chats, setChats] = useState<Record<string, Message[]>>({
    gemini: [],
    sambanova: [],
    cloudflare: []
  });

  const messages = chats[selectedModel] || [];

  const handleSend = async (text: string) => {
    setIsLanding(false);
    
    const userMsgId = crypto.randomUUID();
    const assistantMsgId = crypto.randomUUID();
    
    const initialMessages = [...messages];
    
    const newMessages: Message[] = [
      ...initialMessages,
      { id: userMsgId, role: 'user', content: text },
      { id: assistantMsgId, role: 'assistant', content: '', isStreaming: true }
    ];
    
    setChats(prev => ({ ...prev, [selectedModel]: newMessages }));
    setIsLoading(true);

    try {
      const messagesForApi: ChatMessageData[] = newMessages
        .filter(m => m.id !== assistantMsgId)
        .map(m => ({ role: m.role, content: m.content }));

      const stream = generateChatStream(
        selectedModel as ModelType, 
        messagesForApi
      );

      let fullContent = '';
      for await (const chunk of stream) {
        fullContent += chunk;
        setChats(prev => {
          const updated = prev[selectedModel].map(m => 
            m.id === assistantMsgId ? { ...m, content: fullContent } : m
          );
          return { ...prev, [selectedModel]: updated };
        });
      }
    } catch (error) {
      console.error(error);
      setChats(prev => {
        const updated = prev[selectedModel].map(m => 
          m.id === assistantMsgId ? { ...m, content: 'SYSTEM FAILURE. Unable to process neural link.', isStreaming: false } : m
        );
        return { ...prev, [selectedModel]: updated };
      });
    } finally {
      setChats(prev => {
        const updated = prev[selectedModel].map(m => 
          m.id === assistantMsgId ? { ...m, isStreaming: false } : m
        );
        return { ...prev, [selectedModel]: updated };
      });
      setIsLoading(false);
    }
  };

  const startNewChat = () => {
    setChats(prev => ({ ...prev, [selectedModel]: [] }));
    setIsLanding(true);
    setIsMobileSidebarOpen(false);
  };

  return (
    <div className="relative min-h-screen flex text-[#ededed] overflow-hidden bg-[#050505]">
      <AnimatedBackground />
      
      {!isLanding && (
        <Sidebar 
          onNewChat={startNewChat}
          isMobileOpen={isMobileSidebarOpen}
          setMobileOpen={setIsMobileSidebarOpen}
          selectedModel={selectedModel}
          setSelectedModel={setSelectedModel}
        />
      )}

      {/* Main Content Area */}
      <main className={`flex-1 flex flex-col h-screen relative z-10 ${isLanding ? 'w-full' : ''}`}>
        
        {/* Header during Chat */}
        {!isLanding && (
          <header className="flex items-center justify-between p-4 px-6 border-b border-white/5 bg-[#0a0a0a]/80 backdrop-blur-md z-20">
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => setIsMobileSidebarOpen(true)} 
                className="md:hidden p-2 -ml-2 bg-white/5 rounded-lg border border-white/10 hover:bg-white/10 transition"
              >
                <Menu className="w-5 h-5 text-white/80" />
              </button>
              <div>
                <h1 className="text-lg md:text-xl font-bold tracking-tight text-white/90 font-serif">
                  Hellx <span className="font-light text-white/50">A.I</span>
                </h1>
                <div className="text-[10px] text-white/40 uppercase tracking-widest font-mono">
                  {selectedModel === 'gemini' ? 'Ultra Model Active' : selectedModel === 'sambanova' ? 'Nova Model Active' : 'Cloud Model Active'}
                </div>
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-3 text-xs text-white/30 font-mono uppercase tracking-widest">
              <span>Status: <span className="text-[#a3a3a3]">Optimal</span></span>
            </div>
          </header>
        )}

        <AnimatePresence mode="wait">
          {isLanding ? (
            <motion.div 
              key="landing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0, filter: 'blur(10px)' }}
              transition={{ duration: 0.6 }}
              className="flex-1 flex flex-col items-center justify-center relative p-6 w-full"
            >
              <motion.div 
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.1 }}
                className="text-center relative z-10 w-full max-w-3xl"
              >
                {/* 3 Model Selector on Landing */}
                <div className="flex justify-center gap-3 mb-12">
                   {['gemini', 'sambanova', 'cloudflare'].map((id) => (
                      <button
                        key={id}
                        onClick={() => setSelectedModel(id)}
                        className={`px-4 py-2 rounded-full text-xs font-medium border transition-all ${
                          selectedModel === id 
                            ? 'bg-white text-black border-white shadow-[0_0_20px_rgba(255,255,255,0.2)]'
                            : 'bg-white/5 text-white/50 border-white/5 hover:bg-white/10'
                        }`}
                      >
                        {id === 'gemini' ? 'Hellx Ultra' : id === 'sambanova' ? 'Hellx Nova' : 'Hellx Cloud'}
                      </button>
                   ))}
                </div>

                <h1 className="text-5xl md:text-7xl font-semibold tracking-tight mb-5 text-white font-serif">
                  Hellx <span className="text-white/30">A.I</span>
                </h1>
                
                <p className="text-white/40 text-lg md:text-xl tracking-wide mb-10 max-w-xl mx-auto font-light">
                  Advanced multi-model intelligence. Clean, optimized, ready.
                </p>
                
                <div className="w-full">
                   <ChatInput onSend={handleSend} disabled={false} />
                </div>
              </motion.div>
            </motion.div>
          ) : (
            <motion.div 
              key="chat"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex-1 flex flex-col overflow-hidden w-full relative z-10"
            >
              <ChatArea messages={messages} isLoading={isLoading} selectedModel={selectedModel} />
              
              {/* Footer wrapping ChatInput */}
              <footer className="bg-gradient-to-t from-[#050505] via-[#050505]/95 to-transparent pt-8 pb-4 relative z-20 shrink-0">
                <ChatInput onSend={handleSend} disabled={isLoading} />
              </footer>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

    </div>
  );
}

