# Hellx A.I

Ultra-premium, Next-Gen AI Conversational Interface.

## Deployment to Cloudflare Pages

This frontend project is fully optimized as a Static Single Page Application (SPA).

1. Ensure your codebase is pushed to a GitHub/GitLab repository.
2. In the Cloudflare Dashboard, go to **Workers & Pages** -> **Create application** -> **Pages** -> **Connect to Git**.
3. Select your repository.
4. Use the following build settings:
   - **Framework preset**: `None` (or `Vite`)
   - **Build command**: `npm run build`
   - **Build output directory**: `dist`
5. Add your Environment Variables in the Cloudflare Dashboard:
   - `VITE_GEMINI_API_KEY=your_gemini_key`
6. Click **Save and Deploy**.

### Notes on Framework:
While Hellx A.I was designed to easily drop into a Next.js 15 (App Router) project structure using the included `next.config.js`, this real-time sandbox uses React + Vite to ensure instant Hot-Module-Replacement and 0-configuration live previews. 

Both methods generate a pure static artifact that Cloudflare Pages hosts perfectly. The `_redirects` file is included to ensure client-side routing works smoothly.

### Features
* **Multi-Model Support**: Extensible `ai-models.ts` connector.
* **Animated UI**: Buttery smooth transitions via Framer Motion & CSS.
* **Ambient Backgrounds**: Real-time CSS mixed with Framer for glow effects.
* **Markdown/Syntax Highlighting**: Beautiful code blocks.
