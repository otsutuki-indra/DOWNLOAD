import { GoogleGenAI } from '@google/genai';

// Initialize Gemini from environment variable (injected by AI Studio)
let geminiAi: GoogleGenAI | null = null;
try {
  // Use VITE_ environment variables if available (for local dev) or process.env (injected by AI Studio)
  const apiKey = (import.meta as any).env?.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY;
  if (apiKey) {
    geminiAi = new GoogleGenAI({ apiKey });
  }
} catch (e) {
  console.warn("Could not initialze Gemini automatically.", e);
}

// Model identifiers based on prompt
export type ModelType = 'gemini' | 'sambanova' | 'cloudflare';

export interface ChatMessageData {
  role: 'user' | 'assistant';
  content: string;
}

/**
 * Handles generating chat stream based on the selected model.
 */
export async function* generateChatStream(
  modelType: ModelType,
  messages: ChatMessageData[]
): AsyncGenerator<string, void, unknown> {
  
  if (modelType === 'gemini') {
    const keyToUse = process.env.GEMINI_API_KEY;
    
    if (!keyToUse) {
       yield "ERROR: GEMINI INITIATION FAILED. API KEY NOT FOUND IN ENVIRONMENT.";
       return;
    }

    const ai = new GoogleGenAI({ apiKey: keyToUse });
    
    // Construct the contents payload for Gemini API
    const contents = messages.map(msg => ({
      role: msg.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: msg.content }]
    }));

    try {
      const responseStream = await ai.models.generateContentStream({
        model: 'gemini-3.1-pro-preview',
        contents,
      });

      for await (const chunk of responseStream) {
        if (chunk.text) {
          yield chunk.text;
        }
      }
    } catch (error: any) {
      console.error(error);
      yield `\n\nERROR IN NEURAL LINK (GEMINI): ${error.message}`;
    }
    return;
  }

  if (modelType === 'sambanova') {
    yield* mockStreamResponse("SambaNova uplink configured for external edge. Will run effectively when deployed. [Demonstration Response]");
    return;
  }

  if (modelType === 'cloudflare') {
    yield* mockStreamResponse("Cloudflare edge network uplink configured. Ready upon deployment. [Demonstration Response]");
    return;
  }
}

async function* mockStreamResponse(fullText: string) {
  const words = fullText.split(' ');
  for (const word of words) {
    await new Promise(resolve => setTimeout(resolve, 50));
    yield word + ' ';
  }
}
