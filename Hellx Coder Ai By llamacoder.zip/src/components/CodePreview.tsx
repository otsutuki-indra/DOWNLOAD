import React, { useState, useEffect } from 'react';
import { Message } from '../types';
import { motion, AnimatePresence } from 'framer-motion';
import { Copy, Check } from 'lucide-react';

interface CodePreviewProps {
  messages: Message[];
}

const CodePreview: React.FC<CodePreviewProps> = ({ messages }) => {
  const [copied, setCopied] = useState(false);
  const latestCodeMessage = [...messages].reverse().find(msg => msg.code);

  const handleCopy = () => {
    if (latestCodeMessage?.code) {
      navigator.clipboard.writeText(latestCodeMessage.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b border-slate-700/30 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-red-500"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
          <div className="w-3 h-3 rounded-full bg-green-500"></div>
        </div>
        
        {latestCodeMessage?.code && (
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 text-xs px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 transition-colors"
          >
            {copied ? (
              <>
                <Check size={14} className="text-green-500" />
                <span>Copied!</span>
              </>
            ) : (
              <>
                <Copy size={14} />
                <span>Copy Code</span>
              </>
            )}
          </button>
        )}
      </div>
      
      <div className="flex-1 overflow-auto p-4">
        <AnimatePresence mode="wait">
          {latestCodeMessage ? (
            <motion.div
              key={latestCodeMessage.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="bg-slate-900/80 rounded-lg border border-slate-700/30 overflow-hidden"
            >
              <pre className="p-4 text-sm overflow-auto">
                <code className="font-mono text-slate-100">
                  {latestCodeMessage.code}
                </code>
              </pre>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="h-full flex flex-col items-center justify-center text-slate-500"
            >
              <div className="bg-slate-800/50 border border-dashed border-slate-700/50 rounded-xl w-16 h-16 flex items-center justify-center mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="16 18 22 12 16 6"></polyline>
                  <polyline points="8 6 2 12 8 18"></polyline>
                </svg>
              </div>
              <p className="text-center max-w-xs">
                Code preview will appear here once the assistant generates code
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default CodePreview;