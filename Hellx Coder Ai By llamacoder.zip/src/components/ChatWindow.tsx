import React from 'react';
import { Message } from '../types';
import { motion } from 'framer-motion';
import { Bot, User } from 'lucide-react';

interface ChatWindowProps {
  messages: Message[];
  isTyping: boolean;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isTyping }) => {
  return (
    <div className="space-y-6">
      {messages.map((message) => (
        <motion.div
          key={message.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
        >
          <div className={`flex gap-3 max-w-[85%] ${message.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
              message.role === 'user' 
                ? 'bg-emerald-600' 
                : 'bg-slate-700 border border-emerald-900/50'
            }`}>
              {message.role === 'user' ? (
                <User size={16} className="text-white" />
              ) : (
                <Bot size={16} className="text-emerald-400" />
              )}
            </div>
            
            <div className={`rounded-2xl px-4 py-3 ${
              message.role === 'user'
                ? 'bg-emerald-700/50 border border-emerald-600/30'
                : 'bg-slate-800/50 border border-slate-700/30'
            }`}>
              <div className="font-mono text-sm whitespace-pre-wrap">
                {message.content}
              </div>
            </div>
          </div>
        </motion.div>
      ))}
      
      {isTyping && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex justify-start"
        >
          <div className="flex gap-3">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-700 border border-emerald-900/50 flex items-center justify-center">
              <Bot size={16} className="text-emerald-400" />
            </div>
            <div className="bg-slate-800/50 border border-slate-700/30 rounded-2xl px-4 py-3">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default ChatWindow;