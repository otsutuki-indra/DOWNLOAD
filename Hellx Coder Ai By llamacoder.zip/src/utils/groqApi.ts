const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';

export const fetchGroqResponse = async (prompt: string): Promise<{ reply: string; code: string }> => {
  const response = await fetch(GROQ_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${process.env.GROQ_API_KEY}`
    },
    body: JSON.stringify({
      model: "llama3-8b-8192",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
      max_tokens: 1024,
    })
  });

  if (!response.ok) {
    throw new Error(`API error: ${response.status}`);
  }

  const data = await response.json();
  const content = data.choices[0].message.content;
  
  // Extract code from markdown code blocks
  const codeMatch = content.match(/```(?:\w+)?\n([\s\S]*?)\n```/);
  const code = codeMatch ? codeMatch[1] : '';
  const reply = content.replace(/```(?:\w+)?\n[\s\S]*?\n```/, '').trim();

  return { reply, code };
};