// Mock API function to simulate Groq response
export const mockGroqResponse = async (prompt: string): Promise<{ reply: string; code: string }> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  // Generate mock code based on prompt keywords
  let code = '';
  let reply = '';
  
  if (prompt.toLowerCase().includes('button')) {
    code = `// React Button Component
import React from 'react';

const Button = ({ children, variant = 'primary', onClick }) => {
  const baseClasses = 'px-4 py-2 rounded font-medium transition-colors';
  const variantClasses = {
    primary: 'bg-emerald-600 hover:bg-emerald-500 text-white',
    secondary: 'bg-slate-700 hover:bg-slate-600 text-slate-100',
    outline: 'border border-emerald-500 text-emerald-400 hover:bg-emerald-900/30'
  };
  
  return (
    <button 
      className={\`\${baseClasses} \${variantClasses[variant]}\`}
      onClick={onClick}
    >
      {children}
    </button>
  );
};

export default Button;`;
    reply = "I've created a customizable React button component with three variants: primary, secondary, and outline. The component uses Tailwind classes for styling and includes hover effects.";
  } 
  else if (prompt.toLowerCase().includes('api')) {
    code = `// API Service Utility
const apiService = {
  baseUrl: 'https://api.example.com',
  
  async request(endpoint, options = {}) {
    const url = \`\${this.baseUrl}\${endpoint}\`;
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };
    
    try {
      const response = await fetch(url, config);
      if (!response.ok) {
        throw new Error(\`HTTP error! status: \${response.status}\`);
      }
      return await response.json();
    } catch (error) {
      console.error('API request failed:', error);
      throw error;
    }
  },
  
  get(endpoint, options) {
    return this.request(endpoint, { ...options, method: 'GET' });
  },
  
  post(endpoint, data, options) {
    return this.request(endpoint, {
      ...options,
      method: 'POST',
      body: JSON.stringify(data),
    });
  },
};

export default apiService;`;
    reply = "Here's a reusable API service utility with methods for GET and POST requests. It includes error handling and customizable headers.";
  }
  else {
    code = `// Generated Solution
function solution(input) {
  // Process the input
  const result = input
    .split('\\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .map(line => {
      // Transform each line
      return line.toUpperCase();
    });
  
  return result;
}

// Example usage:
// const output = solution("hello\\nworld");
// console.log(output); // ["HELLO", "WORLD"]`;
    reply = "I've generated a solution based on your request. This function processes multi-line input, trims whitespace, removes empty lines, and converts text to uppercase.";
  }
  
  return { reply, code };
};