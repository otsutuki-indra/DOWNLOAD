import React, { useState, useRef, useEffect } from 'react';
import ChatWindow from './components/ChatWindow';
import CodePreview from './components/CodePreview';
import { Message } from './types';

const App = () => {
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', role: 'assistant', content: 'Hello! I\'m your coding assistant. Describe what you need and I\'ll generate the code for you.' }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const fetchGroqResponse = async (prompt: string): Promise<{ reply: string; code: string }> => {
    try {
      const response = await fetch('/api/groq', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt }),
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();
      
      // Extract code from markdown code blocks
      const codeMatch = data.content.match(/```(?:\w+)?\n([\s\S]*?)\n```/);
      const code = codeMatch ? codeMatch[1] : '';
      const reply = data.content.replace(/```(?:\w+)?\n[\s\S]*?\n```/, '').trim();

      return { reply, code };
    } catch (error) {
      console.error('API call failed:', error);
      return { 
        reply: 'Sorry, I encountered an error. Please try again.', 
        code: '// Error occurred' 
      };
    }
  };

  const handleSend = async () => {
    if (!inputValue.trim() || isTyping) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    try {
      const response = await fetchGroqResponse(inputValue);
      
      const assistantMessage: Message = {
        id: Date.now().toString(),
        role: 'assistant',
        content: response.reply,
        code: response.code
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: Date.now().toString(),
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try again.'
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-emerald-900/20 to-slate-900 p-4 md:p-8">
      <div className="mx-auto max-w-7xl h-[calc(100vh-2rem)] flex flex-col glassmorphic-border rounded-2xl overflow-hidden">
        <div className="flex-1 flex flex-col md:flex-row">
          {/* Chat Window */}
          <div className="w-full md:w-1/2 border-r border-emerald-900/30 flex flex-col">
            <div className="p-4 border-b border-emerald-900/30 bg-slate-900/40 backdrop-blur-sm">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                <h1 className="text-xl font-mono font-bold text-emerald-400">HELLX_CODER</h1>
                <span className="text-xs text-emerald-600 bg-emerald-900/30 px-2 py-1 rounded">v1.0.0</span>
              </div>
              <p className="text-xs text-slate-400 mt-1">AI-powered code generation assistant</p>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 bg-slate-900/20 backdrop-blur-sm">
              <ChatWindow messages={messages} isTyping={isTyping} />
              <div ref={messagesEndRef} />
            </div>
            
            <div className="p-4 border-t border-emerald-900/30 bg-slate-900/40 backdrop-blur-sm">
              <div className="flex gap-2">
                <textarea
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Describe your coding task..."
                  className="flex-1 bg-slate-800/50 border border-emerald-900/50 rounded-lg py-3 px-4 text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-500 resize-none"
                  rows={2}
                  disabled={isTyping}
                />
                <button
                  onClick={handleSend}
                  disabled={!inputValue.trim() || isTyping}
                  className="self-end h-12 w-12 flex items-center justify-center rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="22" y1="2" x2="11" y2="13"></line>
                    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                  </svg>
                </button>
              </div>
              <p className="text-xs text-slate-500 mt-2">Press Enter to send, Shift+Enter for new line</p>
            </div>
          </div>
          
          {/* Code Preview */}
          <div className="w-full md:w-1/2 flex flex-col">
            <div className="p-4 border-b border-emerald-900/30 bg-slate-900/40 backdrop-blur-sm">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                <h2 className="text-xl font-mono font-bold text-amber-400">CODE_PREVIEW</h2>
                <span className="text-xs text-amber-600 bg-amber-900/30 px-2 py-1 rounded">LIVE</span>
              </div>
              <p className="text-xs text-slate-400 mt-1">Real-time code generation output</p>
            </div>
            
            <div className="flex-1 overflow-auto bg-slate-900/20 backdrop-blur-sm">
              <CodePreview messages={messages} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;